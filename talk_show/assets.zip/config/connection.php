<?php 
	mysql_connect("localhost","dapps","l1m4d1g1t") or die("Cant Connect to Server");
	mysql_select_db("dapps_joker_pertamina_luckydip") or die("Cant Found Database");
	// $con=mysqli_connect("localhost","dapps","l1m4d1g1t","dapps_joker_pertamina_luckyfriday");
 ?>
