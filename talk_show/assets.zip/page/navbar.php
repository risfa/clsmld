 <?php 
 if(!empty($_SESSION['id_spbu'])){
   ?> 
   <div class="row">
    <div  style="margin-top: 3vh;">
      <div class="col-md-12">
        <img style="height: 30px; " src="http://pertaminaroadtoeuro4.com/turboact/images/pertaction/logo-pert.png">
      </div>
      <div class="col-md-12">
        <table>
          <tr>
            <td rowspan="2">
              <h3><?php echo "<b>".$_SESSION['nomor_spbu']."</b>"; ?></h3>
            </td>
          </tr>

          <tr>
            <td style="padding-left: 10px;">
               <font><?php echo $_SESSION['alamat_spbu']; ?></font><br>
               <font style="text-transform: uppercase;"><?php echo $_SESSION['kota']; ?></font>
            </td>
          </tr>

        </table>
        <div class="pj_notch">
          <?php echo "Halo, <b>".$_SESSION['pj']."</b>"; ?>
        </div>
       <!--  <ul class="ul_menu" style="margin-left: -38px;">
          <li></li>
        </ul> -->
      </div>
      <div style="clear: both;"></div>
      <hr>
    </div>
  </div>

  <style type="text/css">
  .pj_notch{
    background: white;
    border-radius: 0px 0px 0px 6px;
    position: absolute;
    color: green;
    padding: 4px;
    top: -50px;
    right: 0;
  }
</style>
<?php } ?> 