<?php  
 $connect = mysqli_connect("localhost", "dapps", "l1m4d1g1t", "dapps_joker_pertamina_luckydip");  
 $output = '';  
 $sql = "SELECT * FROM tb_transaksi where id_spbu = '$_GET[idspbu]' ORDER BY id_transaksi DESC";  
 $result = mysqli_query($connect, $sql);  
//   $transaksi = mysqli_fetch_array(mysqli_query($connect,"SELECT COUNT(id_transaksi) FROM `tb_transaksi` WHERE id_spbu = 13"));
//   if ($transaksi_sebelumnya < $transaksi[0]) {
//     $status+=1;
//   }else{
//     echo "tidak lebih besar";
//   }
// $transaksi_sebelumnya = $transaksi[0];                            
// echo'ini transaksi awal'. $transaksi[0];
// echo'ini transaksi akhir'. $transaksi_sebelumnya;
// echo'ini status'. $status;
 $output .= '  
      <div class="col-md-7">  
           <table class="table table-bordered">  
                <tr>  
                     <th width="10%">Tanggal</th>  
                     <th width="10%">KodeTRX</th>  
                     <th width="40%">Nominal</th>  
                     <th width="40%">Customer</th>  
                     <th width="40%">Kendaraan</th> 
                     <th width="40%">PJ</th> 
                     <th width="40%">Hadiah</th> 
                     <th width="40%">Foto</th>  
                </tr>';  

 if(mysqli_num_rows($result) > 0)  
 {  
      while($row = mysqli_fetch_array($result))  
      {  
       $data_spbu = mysqli_fetch_array(mysqli_query($connect,"SELECT * FROM tb_spbu WHERE id_spbu = '$row[id_spbu]'"));
    $data_customer = mysqli_fetch_array(mysqli_query($connect,"SELECT * FROM tb_customer WHERE id_customer = '$row[id_customer]'"));
           $output .= '  
                <tr>  
                     <td class="first_name" data-id1="'.$row["id_transaksi"].'" contenteditable>'.$row["tanggal_transaksi"].'</td>  
                     <td class="first_name" data-id1="'.$row["id_transaksi"].'" contenteditable>'.$row[0].'</td>  
                     <td class="first_name" data-id1="'.$row["id_transaksi"].'" contenteditable>'.number_format($row['nominal_belanja'],0,".",".").'</td>  
                     <td class="first_name" data-id1="'.$row["id_transaksi"].'" contenteditable>'.$data_customer['nama_customer'].'<br>'.$data_customer['no_hp'].'</td>  
                     <td class="first_name" data-id1="'.$row["id_transaksi"].'" contenteditable>'.$row['jenis_kendaraan'].'</td>    
                     <td class="first_name" data-id1="'.$row["id_transaksi"].'" contenteditable>'.$row["penanggung_jawab"].'</td>   
                     <td class="first_name" data-id1="'.$row["id_transaksi"].'" contenteditable>'.$row["hadiahnya"].'</td>';


                      $output .= '<td><a target="blank" href="../assets/strukBBM/'.$row['id_transaksi'].'.jpg"><img style="height: 50px; width:50px;" src="../assets/strukBBM/'.$row['id_transaksi'].'.jpg"></a></td>';


          
            $output .= ' </tr>  
           ';  
      }  
      $output .= '  
           <tr>  
                <td></td>  
                <td id="first_name" contenteditable></td>  
                <td id="last_name" contenteditable></td>  
                <td><button type="button" name="btn_add" id="btn_add" class="btn btn-xs btn-success">+</button></td>  
           </tr>  
      ';  
 }  
 else  
 {  
      $output .= '<tr>  
                          <td colspan="7">No Transaction Available</td>  
                     </tr>';  
 }  
 $output .= '</table>  
      </div>';  
 echo $output;  
 ?>