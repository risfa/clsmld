<?php  
$connect = mysqli_connect("localhost", "dapps", "l1m4d1g1t", "dapps_joker_pertamina_luckydip");  
$output = '';  
$transaksi_sebelumnya = 0; 

$id_spbu = $_GET['idspbu'];
$sql2 = "SELECT * FROM tb_spbu WHERE id_spbu = '$id_spbu'";

$result2 = mysqli_query($connect,$sql2);
while ($data = mysqli_fetch_array($result2)) {
// kotak paling atas
  $total_jumlah_awal = 0;
  $total_jumlah_hadiah = 0;
  $total_sisa_hadiahnya = 0;
  $output .= '<div class="col-md-5" style="border: 1px solid #BABABA; margin-top: 20px;"><br>';
  $output .= '<b style="font-size: 20px;">['.$data[1].']</b>
  <p>'.$data[2].' | '.$data[5].'</p>
  <hr>
  <table style="width: 100%; text-align: center; margin-top: -20px;">
  <tr style="font-size: 50px; font-weight: bold;">
  <td>';
  $hadiah_awal = mysqli_fetch_array(mysqli_query($connect,"SELECT SUM(total_awal) FROM tb_hadiah WHERE id_spbu = '$id_spbu' "));
  $output .= $hadiah_awal[0];
  $output .= '</td>';
  $output .= ' <td>';

  $transaksi = mysqli_fetch_array(mysqli_query($connect,"SELECT COUNT(id_transaksi) FROM tb_transaksi WHERE id_spbu = '$data[0]' AND hadiahnya != ''"));
  
  $output.= $transaksi[0];
  $output .=   '</td>';
  $output .= '<td>';
  $output .=  $hadiah_awal[0] - $transaksi[0];
  $output.= '</td>
  </tr>';
  $output .= '<tr>
  <td>Hadiah Awal</td>
  <td>Transaksi</td>
  <td>Sisa Hadiah</td>
  </tr>
  </table><br>';
  

   // kotak di bawah
  
  $output .= '  
  <table border="1" class="table">
<tr style="font-weight: bold; color: white; background: #BABABA">
                      <td>Hadiah</td>
                      <td>Kategori</td>
                      <td>Awal</td>
                      <td>Trx</td>
                      <td>Sisa DB</td>
                      <td>Status</td>
                    </tr>';   
  $sql = "SELECT * FROM tb_hadiah WHERE id_spbu = '$data[0]' ";  
  $result = mysqli_query($connect, $sql);  
  
  while($hadiahnya = mysqli_fetch_array($result))  
  {  

     if($hadiahnya[5]=='1'){
            $kategori = 'Mobil';
          }else if($hadiahnya[5]=='2'){
            $kategori = 'Motor';
          }else{
            $kategori = 'Umum';
          }


      // if($hadiahnya['jumlah_hadiah']<=0){
      //   // echo $hadiahnya['jumlah_hadiah'];
      //   $status = 'style="background:red; color:white; font-weight:bold"';
      // }else{
      //   $Status = '';
      // }

    $output .= '  
    <tr '.$status.' >
    <td> <b>'.$hadiahnya[0].'</b>|'.$hadiahnya[1].' </td>
    <td> '.$kategori.' </td>
    <td>'.$hadiahnya['total_awal'].' </td>
    <td>
    ';  
    $total_jumlah_awal += $hadiahnya['total_awal'];
    $total_sisa_hadiahnya += $hadiahnya['jumlah_hadiah'];

    $sqljumlahhadiahtrx = mysqli_fetch_array(mysqli_query($connect,"SELECT COUNT(hadiahnya) FROM tb_transaksi WHERE id_spbu = '$data[0]' AND hadiahnya = '$hadiahnya[nama_hadiah]'"));
    $total_jumlah_hadiah += $sqljumlahhadiahtrx[0];
    $output .= $sqljumlahhadiahtrx[0];
    $output.= '</td>
    <td>'.$hadiahnya['jumlah_hadiah'] .'</td>
    <td>
    ';

    if($hadiahnya['jumlah_hadiah']>0){
      if($hadiahnya['status_hadiah']=='AKTIF'){
        $output.= "<label onclick=disAktif('" . $hadiahnya['id_hadiah']. "')   class='label label-success'>".$hadiahnya['status_hadiah']."</label>"; 
      }else if($hadiahnya['status_hadiah']=='DISAKTIF'){
        $output.= "<label onclick=aktif('" . $hadiahnya['id_hadiah']. "') class='label label-danger'>".$hadiahnya['status_hadiah']."</label>"; 
      }
    }else{
        $output.= "<label    class='label label-warning'>HABIS</label>"; 
    }
    
  }   

    
  $output .= '</td></tr><tr><td colspan="2">TOTAL</td><td>'.$total_jumlah_awal.'</td><td>'.$total_jumlah_hadiah.'</td><td>'.$total_sisa_hadiahnya.'</td></tr></table>';


// end

  // end kotak baru
  $output .= '</div>';
}

// $output .= '<div class="col-md-4" style="border: 1px solid #BABABA; margin-top: 20px;"><br>
// <table class="table table-bordered">  
// <tr>  
// <th>Nama Customer</th>  
// <th>Nomor Hp</th>  
// </tr>';

// $result_customer = mysqli_query($connect,"SELECT * FROM `tb_customer` INNER JOIN tb_transaksi on tb_transaksi.id_customer =tb_customer.id_customer WHERE tb_transaksi.id_spbu = '$id_spbu' ORDER BY (tb_transaksi.id_transaksi) DESC LIMIT 7");

// if(mysqli_num_rows($result_customer) > 0)  
// {  
//   while($row_customer = mysqli_fetch_array($result_customer))  
//   {  
   
//     $output.='<tr>';
    
    
//     $output .= '<td> '.$row_customer[1].' </td>
//     <td>'.$row_customer[2].' </td>';

//     $output .= '</tr>';
    
//   }
// }
// $output .='</table>  
// </div>';






echo $output;  
?>
