<?php
// memanggil file config.php
include "dbconnect.php";
// require 'dbconnect.php';
?>
<html>
<head>
	<title>Lihat transaksi luckyfriday</title>
	<link rel="stylesheet" type="text/css" href="assets/css/jquery.dataTables.css">
    <meta name="viewport" content="width=device-width, initial-scale=1">
</head>
<body>
	<h1>DATA TRANSAKSI</h1>
    <div class="row">
    <div  class="col-xs-12 col-sm-12 col-md-12 col-lg-12 col-xl-12" style="margin-top: 50px;">
        <a href="export-excel.php">Export To Excel</a>
	<table id="example" class="display" cellspacing="0" width="100%">
        <thead>
            <tr>
                <!-- <th>Kode TRX</th> -->
                <th>Tanggal</th>
                <th>SPBU</th>
                <th>Nominal</th>
                <th>Customer</th>
                <th>Kendaraan</th>
                <th>PJ</th>
                <th>Hadiah</th>
                <th>Foto</th>
            </tr>
        </thead>
        <tbody>
        <?php
        $sql = "SELECT * FROM  tb_transaksi WHERE hadiahnya !='' ORDER BY RAND()";
        $query = mysql_query($sql);

        while ($row = mysql_fetch_array($query)){


    $data_spbu = mysql_fetch_array(mysql_query("SELECT * FROM tb_spbu WHERE id_spbu = '$row[id_spbu]'"));
    $data_customer = mysql_fetch_array(mysql_query("SELECT * FROM tb_customer WHERE id_customer = '$row[id_customer]'"));

        ?>

        	<tr>
                <!-- <td><?php echo $row['id_transaksi'];?></td> -->
                <td><?php echo $row['tanggal_transaksi'];?></td>
                <td><?php echo $data_spbu['nomor_spbu'];?></td>
                <td><?php echo number_format($row['nominal_belanja'],0,".",".");?></td>
                <td><?php echo $data_customer['nama_customer']."<br>".$data_customer['no_hp'];?></td>
                <td><?php echo $row['jenis_kendaraan'];?></td>
                <td><?php echo $row['penanggung_jawab'];?></td>
                <td><?php echo $row['hadiahnya'];?></td>
        		<td><a target="blank" href="../assets/strukBBM/<?php echo $row['id_transaksi'];?>.jpg"><img style="height: 50px; width:50px;" src="../assets/strukBBM/<?php echo $row['id_transaksi'];?>.jpg"></a></td>

        	</tr>
        <?php } ?>
        </tbody>
    </table>
    </div>
    </div>
	<script type="text/javascript" src="assets/js/jquery.min.js"></script>
	<script type="text/javascript" src="assets/js/jquery.dataTables.min.js"></script>

	<script>
        
    $(document).ready(function() {
	   $('#example').DataTable();
	} );

	</script>


    
</body>
<style>
	.dataTables_length
	{
		float: right !important;
		margin-left: 25px !important;
	}
</style>
</html>